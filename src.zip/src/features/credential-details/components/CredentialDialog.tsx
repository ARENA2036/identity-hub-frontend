import {
  Dialog,
  DialogContent,
  Box,
  Typography,
  Button,
  Grid,
  IconButton,
  Menu,
  MenuItem,
} from "@mui/material";
import { Close, Shield, RemoveCircle, Cached, MoreVert } from "@mui/icons-material";
// @ts-ignore: allow importing image without type declarations
import tractusLogo from "../../../assets/styles/tx.png";
import { useState } from "react";

type CredentialDialogProps = {
  open: boolean;
  onClose: () => void;
  status?: "active" | "inactive"; // will come from backend later
};

export default function CredentialDialog({
  open,
  onClose,
  status = "active",
}: CredentialDialogProps) {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const openMenu = Boolean(anchorEl);

  const handleMenuOpen = (event: React.MouseEvent<HTMLButtonElement>) => {
    setAnchorEl(event.currentTarget);
  };
  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  return (
    <Dialog
      open={open}
      onClose={onClose}
      maxWidth="lg" // ✅ Larger window
      fullWidth
      PaperProps={{
        sx: {
          backgroundColor: "#0d1117",
          color: "#f0f6fc",
          border: "1px solid #30363d",
          borderRadius: 2,
          p: 2,
        },
      }}
    >
      {/* Top Section */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
        {/* Mac-style Close Button (top-left) */}
        <IconButton
          onClick={onClose}
          sx={{
            color: "#f85149",
            "&:hover": { backgroundColor: "rgba(248,81,73,0.2)" },
          }}
        >
          <Close />
        </IconButton>

        {/* Center Status */}
        <Typography
          variant="body1"
          sx={{
            color: status === "active" ? "#3fb950" : "#f85149",
            fontWeight: 600,
          }}
        >
          {status === "active" ? "Active" : "Inactive"}
        </Typography>

        {/* Empty space for alignment */}
        <Box width={40}></Box>
      </Box>

      {/* Main Dialog Body */}
      <DialogContent>
        <Grid container spacing={2}>
          {/* Left Section */}
          <Grid item xs={8}>
            <Typography variant="h6" fontWeight={600}>
              NAME (Subject)
            </Typography>
            <Typography variant="body2" color="#8b949e">
              Type
            </Typography>

            <Box mt={2}>
              <Typography variant="body2" color="#f0f6fc">
                Issuer: did:web:domain.com
              </Typography>
              <Typography variant="body2" color="#f0f6fc">
                Holder: did:web:your-webpage.com
              </Typography>
            </Box>

            <Box mt={2}>
              <Typography variant="body2" color="#8b949e">
                Proof
              </Typography>
              <Box
                sx={{
                  border: "1px solid #30363d",
                  borderRadius: 1,
                  p: 2,
                  mt: 1,
                  minHeight: "80px",
                  backgroundColor: "#161b22",
                  color: "#3fb950",
                }}
              >
                🔒
              </Box>
            </Box>
          </Grid>

          {/* Right Section */}
          <Grid item xs={4}>
            <Box display="flex" flexDirection="column" alignItems="flex-end" gap={1}>
              {/* Action Menu Button */}
              <IconButton
                size="small"
                onClick={handleMenuOpen}
                sx={{
                  color: "#8b949e",
                  alignSelf: "flex-end",
                  "&:hover": { color: "#58a6ff" },
                }}
              >
                <MoreVert />
              </IconButton>

              <Menu
                anchorEl={anchorEl}
                open={openMenu}
                onClose={handleMenuClose}
                PaperProps={{
                  sx: {
                    backgroundColor: "#161b22",
                    color: "#f0f6fc",
                  },
                }}
              >
                <MenuItem onClick={handleMenuClose}>Action 1</MenuItem>
                <MenuItem onClick={handleMenuClose}>Action 2</MenuItem>
              </Menu>

              {/* Tractus-X Logo */}
              <Box
                component="img"
                src={tractusLogo}
                alt="Tractus-X"
                sx={{
                  width: 80,
                  height: 80,
                  borderRadius: 2,
                  mt: 1,
                  mb: 1,
                }}
              />
              <Typography variant="body2" color="#8b949e">
                Catena-X
              </Typography>

              {/* Created and Expiration Dates */}
              <Typography variant="body2" color="#8b949e">
                Created: 2024-10-10
              </Typography>
              <Typography variant="body2" color="#8b949e">
                Expiration: 2026-10-10
              </Typography>

              {/* Buttons */}
              <Box mt={2} width="100%" display="flex" flexDirection="column" gap={1}>
                <Button
                  startIcon={<Shield />}
                  variant="outlined"
                  sx={{
                    borderColor: "#238636",
                    color: "#3fb950",
                    "&:hover": { backgroundColor: "rgba(63,185,80,0.1)" },
                  }}
                >
                  Verify
                </Button>

                <Button
                  startIcon={<RemoveCircle />}
                  variant="outlined"
                  sx={{
                    borderColor: "#f85149",
                    color: "#f85149",
                    "&:hover": { backgroundColor: "rgba(248,81,73,0.1)" },
                  }}
                >
                  Revoke
                </Button>

                <Button
                  startIcon={<Cached />}
                  variant="outlined"
                  sx={{
                    borderColor: "#58a6ff",
                    color: "#58a6ff",
                    "&:hover": { backgroundColor: "rgba(88,166,255,0.1)" },
                  }}
                  onClick={() => console.log("🔄 Rotate Key - flip card")}
                >
                  Rotate Key
                </Button>
              </Box>
            </Box>
          </Grid>
        </Grid>
      </DialogContent>
    </Dialog>
  );
}
