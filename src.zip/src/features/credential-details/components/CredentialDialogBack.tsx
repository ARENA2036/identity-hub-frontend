import { Box, Typography, Button } from "@mui/material";
import { ArrowBack } from "@mui/icons-material";

type CredentialDialogBackProps = {
  flipped: boolean;
  onFlip: () => void;
};

export default function CredentialDialogBack({
  flipped,
  onFlip,
}: CredentialDialogBackProps) {
  return (
    <Box
      sx={{
        position: "absolute",
        width: "100%",
        height: "100%",
        backfaceVisibility: "hidden",
        transform: "rotateY(180deg)",
        backgroundColor: "#0d1117",
        border: "1px solid #30363d",
        borderRadius: 2,
        p: 3,
        color: "#f0f6fc",
      }}
    >
      <Typography variant="h6" mb={2}>
        🔐 Rotated Key Details (Back Side)
      </Typography>

      <Typography variant="body2" color="#8b949e">
        This area will later contain technical information about key rotation,
        digital signatures, and audit metadata fetched from backend.
      </Typography>

      <Button
        startIcon={<ArrowBack />}
        variant="outlined"
        sx={{
          mt: 4,
          borderColor: "#58a6ff",
          color: "#58a6ff",
          "&:hover": { backgroundColor: "rgba(88,166,255,0.1)" },
        }}
        onClick={onFlip}
      >
        Back to Details
      </Button>
    </Box>
  );
}
