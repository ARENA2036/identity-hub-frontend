import { Card, CardContent, Typography, CardActionArea, Box } from "@mui/material";
// @ts-ignore: allow importing image without type declarations
import tractusLogo from "../../../assets/styles/tx.png"; 

type CredentialCardProps = {
  name: string;
  issuer: string;
  expiry: string;
  onClick: () => void;
};

export default function CredentialCard({ name, issuer, expiry, onClick }: CredentialCardProps) {
  return (
    <Card
      sx={{
        width: 260,
        backgroundColor: "#0d1117",
        border: "1px solid #30363d",
        borderRadius: 2,
        transition: "all 0.2s ease-in-out",
        "&:hover": {
          borderColor: "#58a6ff",
          boxShadow: "0px 0px 8px rgba(88,166,255,0.4)",
          cursor: "pointer",
        },
      }}
    >
      <CardActionArea onClick={onClick}>
        <CardContent>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
            <Typography variant="subtitle1" fontWeight={600} color="#f0f6fc">
              {name}
            </Typography>
            <Box
              component="img"
              src={tractusLogo}
              alt="Tractus-X"
              sx={{ width: 32, height: 32, borderRadius: "4px" }}
            />
          </Box>
          <Typography variant="body2" color="#8b949e">
            Issuer: {issuer}
          </Typography>
          <Typography variant="body2" color="#8b949e">
            Expiry: {expiry}
          </Typography>
        </CardContent>
      </CardActionArea>
    </Card>
  );
}

/*
   Future Integration Note:
  The CredentialCards will be fetched dynamically from backend API.
*/



