import { Box, Typography } from '@mui/material'
import { Grid2 } from "@mui/material";
import { useState } from 'react'
import CredentialCard from '../components/CredentialCard'
import CredentialDialog from '../components/CredentialDialog'

export default function CredentialDetailsPage() {
  const [openDialog, setOpenDialog] = useState(false)

  const credentials = [
    { name: 'Credential 1', issuer: 'did:web:domain.com', expiry: '2026-01-01' },
    { name: 'Credential 2', issuer: 'did:web:domain.com', expiry: '2026-01-01' },
    { name: 'Credential 3', issuer: 'did:web:domain.com', expiry: '2026-01-01' },
    { name: 'Credential 4', issuer: 'did:web:domain.com', expiry: '2026-01-01' },
  ]

  return (
    <Box sx={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', p: 3 }}>
      {/* Page Title — identical structure to Catalog Parts */}
      <Grid2 container direction="column" alignItems="center" sx={{ mb: 3 }}>
        <Grid2 className="product-catalog title flex flex-content-center">
          <Typography className="text">Issuer Wallet</Typography>
        </Grid2>
      </Grid2>

      {/* Credential Cards */}
      <Box display="flex" justifyContent="space-between" flexWrap="wrap" gap={3}>
        {credentials.map((cred, index) => (
          <CredentialCard key={index} {...cred} onClick={() => setOpenDialog(true)} />
        ))}
      </Box>

      <CredentialDialog open={openDialog} onClose={() => setOpenDialog(false)} />
    </Box>
  )
}
