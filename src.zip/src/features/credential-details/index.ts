export { default as CredentialDetailsPage } from './pages/CredentialDetailsPage'
